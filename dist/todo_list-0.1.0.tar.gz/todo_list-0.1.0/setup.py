# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['todo_list',
 'todo_list.src.todo_list',
 'todo_list.src.todo_list.methods',
 'todo_list.tests']

package_data = \
{'': ['*'], 'todo_list': ['src/*'], 'todo_list.src.todo_list': ['data/*']}

install_requires = \
['datetime>=4.7,<5.0',
 'dynaconf>=3.1.11,<4.0.0',
 'pandas>=1.5.1,<2.0.0',
 'pathlib>=1.0.1,<2.0.0',
 'tabulate>=0.9.0,<0.10.0',
 'typer>=0.7.0,<0.8.0']

setup_kwargs = {
    'name': 'todo-list',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Precondiciones\nSe asume que ya tiene Python 3+ instalado en su sistema. Si no, por favor, instalelo.  \n\nRevisar este link acorde a su sistema operativo: \n[Python 3 Installation & Setup Guide](https://realpython.com/installing-python/)\n\nSe asume que se tiene instalado Poetry\n(https://python-poetry.org/docs/#installation)\n\n\n# Instalación de ambiente virtual\nAbra una terminal, y dirijase a la carpeta raiz del proyecto y ejecute el siguiente comando:\n\n```\npoetry env use python\n```\n\n# Instalacion de bibliotecas\nPara instalar las bibliotecas necesarias, use este comando:\n```\npoetry install\n```\n\n¡Listo, la configuración está lista!\n\n## Probando el codigo\nIngresar al folder src\n```\ncd todo_list_proyect/todo_list/src\n```\nRevisando comandos posibles a ejecutar\n```\npoetry run python -m to_do_list --help\n```\n\nListar los archivos\n```\npoetry run python -m to_do_list list\n```\n\nCrear una nueva lista\n```\n \n(opcion 1) poetry run python -m to_do_list create -ln mi-lista\n\n(opcion 2) poetry run python -m to_do_list create --listname mi-lista\n```\n\nMostrar la lista\n```\n(opcion 1) poetry run python -m to_do_list show -ln mi_lista\n\n(opcion 2) poetry run python -m to_do_list show --listname mi-lista\n```\n\n\nAgregar una tarea\n```\n(opcion 1) poetry run python -m to_do_list add -ln mi_lista_jevb -tn "Hacer ejercicio" -d "correr en el parque" -o "Contreras"\n\n(opcion 2) poetry run python -m to_do_list add --listname mi_lista_jevb --taskame "Hacer ejercicio" --description "correr en el parque" --owner "Jose"\n```\n\nActualizar un campo\n```\n(opcion 1) poetry run python -m to_do_list update -ln mi_lista_jevb -i 0 -f status -c done\n\n(opcion 2) poetry run python -m to_do_list update --listname --taskid 0 --field status --change done\n```\n\n\n\n## Ejecutar pruebas unitarias y de integracion\n* Pruebas unitarias\n```\npytest tests/unit/ -v\n```\n\n* Pruebas de integracion\n```\npytest tests/integration/ -v\n```\n',
    'author': 'contrcf',
    'author_email': 'contrf@cat.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
