from todo_list.config import settings, ROOT_DIR
from todo_list.methods.todo_commands import app

if __name__ == "__main__":
    app()
